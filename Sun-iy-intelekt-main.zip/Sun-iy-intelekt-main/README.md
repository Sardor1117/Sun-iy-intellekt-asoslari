Rahmat aytish esdan chiqmasin 😉
